#include <header.h>

int header() {
	printf(".h + .cpp test succeed \n");
	return 0;
}